﻿using System.Linq;
using System.Web.Hosting;
using System.Web.Mvc;

namespace DiMuro.Arthur._5i.XMLReadWrite2.Controllers
{
    public class DefaultController : Controller
    {
        const string fileName = @"~/App_Data/dati.xml";

        // GET: Default
        private Persone person { get; set; }
        // GET: Default
        public ActionResult Index()
        {
            person = new Persone(HostingEnvironment.MapPath(fileName));
            return View(person);
        }


        public ActionResult @event(string a)
        {
            return View(a);
        }

        public ActionResult AddPerson()
        {
            person = new Persone(HostingEnvironment.MapPath(fileName));
            person.Aggiungi();
            return View("Index", person);
        }

        public ActionResult GetContact(int id)
        {
            return View(new Persone(HostingEnvironment.MapPath(fileName)).FirstOrDefault(Persona => Persona.Id == id));
        }
    }
}